/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hseffian <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/30 12:36:32 by hseffian          #+#    #+#             */
/*   Updated: 2019/10/30 12:36:33 by hseffian         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_LS_H
#define FT_LS_H
#define l 1
#define a 2
#define R 4
#include "libft/libft.h"
#include <stdio.h> 
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <pwd.h> 
#include <grp.h>
#include <time.h>

typedef struct s_directory
{
    DIR             *dir;
    struct dirent   *r;
    struct stat   s;
    char            *link;
    char            *Directory[2];
    char            **tab;
    int             i;
    int             opt;
}               t_directory;

int     get_option(char **av, int *index);
void    do_ls_l(char *str);
void	show_file_info(char *filename, struct stat *info_p);
// void open_directory(char *str, int op);
void		dostat(char *link, char *filename);
void open(char *str, t_directory *dir);
void open_directory(char *str, int op);

#endif