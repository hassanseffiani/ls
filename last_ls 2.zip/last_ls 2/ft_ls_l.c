/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls_l.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hseffian <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/03 18:38:11 by hseffian          #+#    #+#             */
/*   Updated: 2019/11/03 19:19:29 by hseffian         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void		mode_to_letters(int mode, char str[])
{
	ft_strcpy(str, "**********");
	str[0] = S_ISDIR(mode) ? 'd' : '-';
	str[1] = (mode & S_IRUSR) ? 'r' : '-';
	str[2] = (mode & S_IWUSR) ? 'w' : '-';
	str[3] = (mode & S_IXUSR) ? 'x' : '-';
	str[4] = (mode & S_IRGRP) ? 'r' : '-';
	str[5] = (mode & S_IWGRP) ? 'w' : '-';
	str[6] = (mode & S_IXGRP) ? 'x' : '-';
	str[7] = (mode & S_IROTH) ? 'r' : '-';
	str[8] = (mode & S_IWOTH) ? 'w' : '-';
	str[9] = (mode & S_IXOTH) ? 'x' : '-';
}

void		show_file_info(char *filename, struct stat *info_p)
{
	char			modestr[11];
	char			usr[10];
	char			grp[10];
	struct passwd	*p;
	struct group	*g;

	g = getgrgid(info_p->st_gid);
	p = getpwuid(info_p->st_uid);
	ft_strcpy(usr, p->pw_name);
	ft_strcpy(grp, g->gr_name);
	mode_to_letters(info_p->st_mode, modestr);
	printf("%s\t%d\t%-8s %-8s ", modestr, info_p->st_nlink, usr, grp);
	printf("%8ld %.12s ", (long)info_p->st_size, 4 + ctime(&info_p->st_mtime));
	printf("%s\n", filename);
	// printf("\n");
}

// void		dostat(char *link, char *filename)
// {
// 	struct stat s;

// 	if (lstat(link, &s) == -1)
// 		perror(filename);
// 	else
// 		show_file_info(filename, &s);
// }

// char		*tab_join(char *str, char *jn)
// {
// 	char		*ret;

// 	ret = ft_strjoin(str, "/");
// 	ret = ft_strjoin(ret, jn);
// 	return (ret);
// }

// void		do_ls_l(char *str)
// {
// 	DIR				*dir;
// 	char			*link;
// 	struct dirent	*r;

// 	if ((dir = opendir(str)) == NULL)
// 		perror("ls");
// 	else
// 	{
// 		while ((r = readdir(dir)) != NULL)
// 		{
// 			if (r->d_name[0] != '.')
// 			{
// 				link = tab_join(str, r->d_name);
// 				dostat(link, r->d_name);
// 			}
// 		}
// 	}
// 	if (dir)
// 		closedir(dir);
// }