
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   do_ls.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hseffian <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/31 22:48:46 by hseffian          #+#    #+#             */
/*   Updated: 2019/10/31 22:48:47 by hseffian         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"


// int check_type(int mode)
// {
//     if (S_ISDIR(mode))
//         return (1);
//     return (0);
// }

// char		*tab_join2(char *str, char *jn)
// {
// 	char		*ret;

// 	ret = ft_strjoin(str, "/");
// 	ret = ft_strjoin(ret, jn);
// 	return (ret);
// }

// void check_r(t_directory *directory)
// {
//     if (directory->Directory[0])
//     {
//         directory->i = 0;
//         directory->tab = ft_strsplit(directory->Directory[0], ':');
//         free(directory->Directory[0]);         
//         while (directory->tab[directory->i])
//         {
//             ft_putstr(directory->tab[directory->i]);
//             ft_putendl(":");
//             open(directory->tab[directory->i], directory);
//             ft_strdel(&directory->tab[directory->i]);
//             directory->i++;
//         }
//         // ft_putchar('P');
//         // if (dir->i != 0)
//         //     free(dir->tab);
//     }
// }

// void open(char *str, t_directory *directory)
// {
//     directory->Directory[0] = ft_strnew(0);
//     if ((directory->dir = opendir(str)) == NULL)
//         perror("ft_lsddasd");
//     else
//     {
//         while ((directory->r = readdir(directory->dir)) != NULL)
//         {
//             if (directory->r->d_name[0] != '.' || (directory->opt & a))
// 			{
// 				directory->link = tab_join2(str, directory->r->d_name);
//                 lstat(directory->link, &directory->s);
//                 if ((directory->opt & R) && check_type(directory->s.st_mode))
//                 {
//                     directory->Directory[1] = ft_strnew(0);
//                     directory->Directory[0] = ft_strjoin(directory->Directory[1], directory->link);
//                     ft_strdel(&directory->Directory[1]);
//                     directory->Directory[1] = directory->Directory[0];
//                     directory->Directory[0] = ft_strjoin(directory->Directory[1], ":");
//                     ft_strdel(&directory->Directory[1]);
//                 }
//                 if (!(directory->opt & l))
//                     printf("%s\t", directory->r->d_name);
//                 else
//                     show_file_info(directory->r->d_name, &directory->s);
//              }
//         } 
//         check_r(directory);
//         // if (directory->dir)
//         // printf("%s", directory->dir);
// 	closedir(directory->dir);
//     }
   
// }

// int main(int ac, char **av)
// {
//     t_directory directory;

//     directory.i = 0;
//     directory.opt = get_option(&*av, &directory.i);
//     if (av[directory.i])
//         open(av[directory.i], &directory);
//     else
//         open(".", &directory);
// }







void ft_ls(const char *str)
{
	DIR     *dir;  
	struct dirent   *r;

    if ((dir = opendir(str)) == NULL)
        perror("lsd");
    else
    {
		while ((r = readdir(dir)) != NULL)
		{ 
            if (r->d_name[0] != '.')
                printf("%s\n", r->d_name);
		}
	}
    if (dir)
	closedir(dir);
}


void ft_ls_a(const char *str)
{
	DIR     *dir;  
	struct dirent   *r;
	struct stat s;
    
    if ((dir = opendir(str)) == NULL)
        perror("ft_ls");
    else
    {
        while ((r = readdir(dir)) != NULL)
        { 
            // printf("%s\t", r->d_name);
            // if (lstat(r->d_name, &s) )
                    printf("%s\t", r->d_name);
            // else
                // perror("ls");
        }
	}
    if (dir)
	closedir(dir);
}

int check_type(int mode)
{
    if (S_ISDIR(mode))
        return (1);
    return (0);
}

char		*tab_join2(char *str, char *jn)
{
	char		*ret;

	ret = ft_strjoin(str, "/");
	ret = ft_strjoin(ret, jn);
	return (ret);
}

void check_r(char **Directory, char **tab, int op)
{
    if (Directory[0])
    {
        int  i = 0;
        tab = ft_strsplit(Directory[0], ':');
        free(Directory[0]);
        while (tab[i])
        {
            ft_putstr(tab[i]);
            ft_putendl(":");
            open_directory(tab[i], op);
            ft_strdel(&tab[i]);
            i++;
        }
        free(tab);
    }
}

void open_directory(char *str, int op)
{
    DIR             *dir;
    struct dirent   *r;
    struct stat     s;
    char			*link;
    char            *Directory[2];
    char            **tab;
    // int size_block;
    // int g = check_type(s.st_mode);
    // ft_putnbr(g);
    Directory[0] = NULL;
    if ((dir = opendir(str)) == NULL)
        perror("ft_ls");
    else
    {
        while ((r = readdir(dir)) != NULL)
        {
            if (r->d_name[0] != '.' || (op & a))
			{
                // size_block += s.st_blocks;
				link = tab_join2(str, r->d_name);
                lstat(link, &s);
                if ((op & R) && check_type(s.st_mode))
                {
                    Directory[1] = Directory[0];
                    Directory[0] = ft_strjoin(Directory[1], link);
                    ft_strdel(&Directory[1]);
                    Directory[1] = Directory[0];
                    Directory[0] = ft_strjoin(Directory[1], ":");
                    ft_strdel(&Directory[1]);
                }
                if (!(op & l))
                    printf("%s\t", r->d_name);
                else
                    show_file_info(link, &s);
                // if (r->d_name[0])
                    // printf("%s ", r->d_name);
                // else
                // printf("\n");
			}
            if (!(op & l))
                printf("\n");
            // printf("\n");
            // if (op & a)
                    // printf("%s\t", r->d_name);
            // printf("\n");
            // printf("%s\t", r->d_name);
            // if ((op & l))
                // dostat(link, r->d_name);
            // else
                //print_detail(str, tab)
            // ft_putchar('\n');
        }
    }
    check_r(Directory, tab,op);
    if (dir)
	    closedir(dir);
}

int main(int ac, char **av)
{
    int i;
    int opt;
    opt = get_option(&*av, &i);
    
    // if (opt & l)
    // {
    //     if (av[i])
    //         do_ls_l(av[i]);
    //     else
    //         do_ls_l(".");
    // }
    if (av[i])
        open_directory(av[i], opt);
    else 
        open_directory(".", opt);
   /* else if (opt & a)
    {
        if (av[i])
            ft_ls_a(av[i]);
        else
            ft_ls_a(".");
    }
    else if (opt & R)
    {
        if(av[i])
            open_directory(av[i], op);
        else
            open_directory(".", op);
    }
    else
    {
        if (av[i])
            ft_ls(av[i]);
        else
            ft_ls(".");
    }*/
	return (0);
}