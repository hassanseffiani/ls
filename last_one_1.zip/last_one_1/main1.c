/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zael-mab <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/03/02 23:12:37 by zael-mab          #+#    #+#             */
/*   Updated: 2020/03/03 04:25:08 by zael-mab         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

int main (int ac, char **av)
{
	ac = 0;
	struct stat sdir;
	struct passwd *pws;
	struct group *grp;
	lstat(av[1], &sdir);
	pws = getpwuid(sdir.st_uid);
	grp = getgrgid(sdir.st_gid);
	
	ft_printf("Nombre de liens: %d\nPropritaire: %s\nGroupe: %s\nTaille: %d octets\n",
			sdir.st_nlink, pws->pw_name, grp->gr_name, sdir.st_size);
	
	ft_printf("Data de derniere modif : %.12s\n", 4+ctime(&sdir.st_mtime));
	ft_printf (S_ISDIR(sdir.st_mode) ? "d" : "-");
	ft_printf ((sdir.st_mode & S_IRUSR) ? "r" : "-");
	ft_printf ((sdir.st_mode & S_IWUSR) ? "w" : "-");
	ft_printf ((sdir.st_mode & S_IXUSR) ? "x" : "-");
	ft_printf ((sdir.st_mode & S_IRGRP) ? "r" : "-");
	ft_printf ((sdir.st_mode & S_IWGRP) ? "w" : "-");
	ft_printf ((sdir.st_mode & S_IXGRP) ? "x" : "-");
	ft_printf ((sdir.st_mode & S_IROTH) ? "r" : "-");
	ft_printf ((sdir.st_mode & S_IWOTH) ? "w" : "-");
	ft_printf ((sdir.st_mode & S_IXOTH) ? "x" : "-");
}


