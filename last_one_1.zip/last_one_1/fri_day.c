/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fri_day.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zael-mab <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/03/06 01:41:00 by zael-mab          #+#    #+#             */
/*   Updated: 2020/03/06 01:41:01 by zael-mab         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void free_tab(t_ls *data)
{
    int x;

    x = 0;
    while (x < data->word_d)
        free(data->tab[x++]);
    free(data->tab);
}

char    *tab_join(t_ls *data, char *tab)
{
    char *ss;

    ss = ft_strjoin(data->str, "/");
    ss = ft_strjoin(ss, tab);
    return (ss);
}

char    *tab_join1(char *str, char *tab)
{
    char *ss;

    ss = ft_strjoin(str, "/");
    ss = ft_strjoin(ss, tab);
    return (ss);
}

void affichage_simple(char **s)
{
   int i;

    i = 0;
    while (s[i] != '\0')
    {
        ft_putstr(s[i]);
        ft_putstr("\n");
        i++;
    }
}

void launch_r(t_ls *data)
{
    int  i = 0;
	char **tab1;
    if (data->tab0[0])
    {
        tab1 = ft_strsplit(data->tab0[0], ':');
        free(data->tab0[0]);
        while (tab1[i])
        {
            ft_printf("%s:\n", tab1[i]);
            // open_directory(tab1[i], 0, data);
            data->str = tab1[i];
            s_orting0(data);
            ft_strdel(&tab1[i]);
            i++;
        }
        free(tab1);
    }
}

char		*tab_join2(char *str, char *jn)
{
	char		*ret;

	ret = ft_strjoin(str, "/");
	ret = ft_strjoin(ret, jn);
	return (ret);
}

void check_r(char **Directory, char **tab, t_ls *data)
{
    if (Directory[0])
    {
        int  i = 0;
        tab = ft_strsplit(Directory[0], ':');
        free(Directory[0]);
        while (tab[i])
        {
            ft_putstr(tab[i]);
            ft_putendl(":");
            open_directory(tab[i], data);
            ft_strdel(&tab[i]);
            i++;
        }
        free(tab);
    }
}

void open_directory(char *str, t_ls *data)
{
    int x;

    x = 0;
    t_open open_f;
    
    open_f.i = -1;
    open_f.Directory[0] = NULL;
    if ((open_f.dir = opendir(str)) != NULL)
    {
        while ((open_f.r = readdir(open_f.dir)) != NULL)
        {
            if (open_f.r->d_name[0] != '.' || (data->op & A))
			{
				open_f.link = tab_join2(str, open_f.r->d_name);
                lstat(open_f.link, &open_f.s);
                if ((data->op & RR) && (S_IFDIR & open_f.s.st_mode))
                {
                    open_f.Directory[1] = open_f.Directory[0];
                    open_f.Directory[0] = ft_strjoin(open_f.Directory[1], open_f.link);
                    ft_strdel(&open_f.Directory[1]);
                    open_f.Directory[1] = open_f.Directory[0];
                    open_f.Directory[0] = ft_strjoin(open_f.Directory[1], ":");
                    ft_strdel(&open_f.Directory[1]);
                }
                open_f.str[++open_f.i] = open_f.r->d_name;
			}
        }
        if (!(data->op & L))
        {
            x = -1;
            while (open_f.str[++x] != '\0')
                ft_printf("%s\n", open_f.str[x]);
        }
        else
            ft_detail(data);        
    }
    check_r(open_f.Directory, open_f.tab, data);
    if (open_f.dir)
	    closedir(open_f.dir);
}

void   s_orting0(t_ls *data)
{
    int x;
    
    x = 0;
    data->tab0[0] = NULL;
    if (data->j >= 2 && data->flag != -1)
        ft_printf ("\n%s:\n", data->str);
    if ((data->dir = opendir(data->str)) != NULL)
    {
        if (!(data->tab = (char **)malloc(sizeof (char *) * data->word_d)))
            perror("allocation faild\n");
        while ((data->r = readdir(data->dir)) != NULL && data->word_d >= x)
        {
            if (!(data->tab[x] = ft_strdup (data->r->d_name)))
                perror("allocation faild\n");
            x++;
        }
        if (data->op & L &&(x > 2 || data->op & A))
            ft_printf ("total %d\n", data->block);
        s_orting1(data);
        s_orting2(data);
        free_tab(data);
    }
    if (data->str)
        closedir(data->dir);
    open_directory(data->str, data);
}




//////////////////////////////////////////////////
 void   s_orting1(t_ls *data)
 {
    int y;
    char *holder;
    struct stat		sdir1;
    struct stat		sdir2;

    data->z = -1;
    while (++data->z < data->word_d - 1)
    {
        y = data->z - 1;
        while (++y < data->word_d)
        {
            if (ft_strcmp (data->tab[data->z], data->tab[y]) > 0 && !(data->op & RN))
            {
                holder = data->tab[data->z];
                data->tab[data->z] = data->tab[y];
                data->tab[y] = holder;
            }
            data->linkx = tab_join(data, data->tab[data->z]);
            data->linky = tab_join(data, data->tab[y]);
            lstat(data->linkx, &sdir1);
            lstat(data->linky, &sdir2);
            if (sdir1.st_mtime < sdir2.st_mtime && (data->op & T) && !(data->op & RN))
            {
                holder = data->tab[data->z];
                data->tab[data->z] = data->tab[y];
                data->tab[y] = holder;
            }
            if (sdir1.st_mtime > sdir2.st_mtime && (data->op & T) && (data->op & RN))
            {
                holder = data->tab[data->z];
                data->tab[data->z] = data->tab[y];
                data->tab[y] = holder;
            }
            if(sdir1.st_mtime == sdir2.st_mtime && (data->op & T) && ft_strcmp (data->tab[data->z], data->tab[y]) < 0 && (data->op & RN))
            {
                holder = data->tab[data->z];
                data->tab[data->z] = data->tab[y];
                data->tab[y] = holder;
            }
            if (ft_strcmp (data->tab[data->z], data->tab[y]) < 0 && (data->op & RN) && !(data->op & T))
            {
                holder = data->tab[data->z];
                data->tab[data->z] = data->tab[y];
                data->tab[y] = holder;
            }
        }
    }
 }


void    s_orting2(t_ls *data)
{
// ************************************
    data->z = -1;
    while (++data->z < data->word_d)
    {
        if (data->tab[data->z][0] != '.' && !(data->op & A) && !(data->op & L))
            ft_printf ("%s\n", data->tab[data->z]);

// **********************>> A <<********************
        if (!(data->op & RN) && !(data->op & L))
        {
            if (data->op & A)
                ft_printf ("%s\n", data->tab[data->z]);
        }
        
// **********************>> L <<********************
        if (data->tab[data->z][0] != '.' && (data->op & L))
        {
            ft_detail(data);
            if (data->x == 'l')
            {
                link_name(data);
                ft_printf("%s -> %s\n", data->tab[data->z], data->linkname);
                free (data->linkname);
            }
            if (data->x != 'l')
                ft_printf ("%s\n", data->tab[data->z]);
        }
        if (data->tab[data->z][0] == '.' && (data->op & L) && (data->op & A))
        {
            ft_detail(data);
            ft_printf ("%s\n", data->tab[data->z]);
        }

// **********************>> RN <<********************
        if (data->op & RN && !(data->op & L) && (data->op & A))
            ft_printf ("%s\n", data->tab[data->z]);
    }
}

///////////////////////////////////////////////////////////