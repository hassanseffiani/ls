/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tst.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zael-mab <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/03/03 04:35:29 by zael-mab          #+#    #+#             */
/*   Updated: 2020/03/03 04:36:00 by zael-mab         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include  "ft_ls.h"

void 	link_name(t_ls *data)
{
    int r;
	char *tt = NULL;
	char *tp = NULL;

    data->linkname = malloc(data->sdir.st_size + 1);
    if (data->linkname == NULL) {
        ft_printf("insufficient memory\n");
        exit(0);
    }
	if (data->c == 'd')
	{
		tp = ft_strjoin(data->str,"/");
		tt = ft_strjoin(tp,data->tab[data->z]);
		lstat(tt, &data->sdir);
		free (tp);
		free (tt);
	}
    r = readlink(tt, data->linkname, data->sdir.st_size + 1);

    if (r < 0 || r > data->sdir.st_size) {
        ft_printf("symlink increased in size "
                "between lstat() and readlink()\n");
        exit(EXIT_FAILURE);
    }
    data->linkname[data->sdir.st_size] = '\0';
}

char        f_type(mode_t mode)
{
    char c = '?';
	if ((mode & S_IFMT) == S_IFBLK)
		c = 'b';
	else if ((mode & S_IFMT) == S_IFCHR)
		c = 'c';
	else if ((mode & S_IFMT) == S_IFDIR)
		c = 'd';
	else if ((mode & S_IFMT) == S_IFIFO)
		c = 'p';
	else if ((mode & S_IFMT) == S_IFLNK)
		c = 'l';
	else if ((mode & S_IFMT) == S_IFREG)
		c = '-';
	else if ((mode & S_IFMT) == S_IFSOCK)
		c = 's';
	else
		c = '?';
    return (c);
}

void        option(char *s, t_ls *data)
{
	size_t  i;
	
	i = 0;
	if (s && s[0] == '-' && s[1])
	{
		i = 0;
		while (s[++i])
		{
			if (s[i] == 'l' && !(data->op & L))
				data->op += L;
			else if (s[i] == 'a' && !(data->op & A))
				data->op += A;
			else if (s[i] == 'R' && !(data->op & RR))
				data->op += RR;
			else if (s[i] == 'r' && !(data->op & RN))
				data->op += RN;
			else if (s[i] == 't' && !(data->op & T))
				data->op += T;
			else if ((data->op & T) || (data->op & RR) || (data->op & L) ||
			(data->op & A) || (data->op & RN))
				i++; 
			else
			{
				ft_printf ("ft_ls: illegal option -- %c\n", s[i]);
				ft_printf ("usage: ft_ls [-alrRt] [file ...]\n");
				exit (0);
			}
		}
	}
	if (s && s[0] == '-' && !s[1])
		ft_printf ("ft_ls: -: No such file or directory\n");
		// ft_printf ("%d\n %d\n %d\n %d\n%d\n  ", (data->op & T), (data->op & RR), (data->op & RN), (data->op & L), (data->op & A));
}

void    ft_detail(t_ls *data)
{
	char *tp = NULL;
	char *tt = NULL;

	if (data->c == 'd')
	{
		tp = ft_strjoin(data->str,"/");
		tt = ft_strjoin(tp,data->tab[data->z]);
		lstat(tt, &data->sdir);
		free (tp);
		free (tt);
	}
	data->pws = getpwuid(data->sdir.st_uid);
	data->grp = getgrgid(data->sdir.st_gid);
	data->x = f_type(data->sdir.st_mode);
	ft_printf("%c", data->x);
	ft_printf ((data->sdir.st_mode & S_IRUSR) ? "r" : "-");
	ft_printf ((data->sdir.st_mode & S_IWUSR) ? "w" : "-");
	ft_printf ((data->sdir.st_mode & S_IXUSR) ? "x" : "-");
	ft_printf ((data->sdir.st_mode & S_IRGRP) ? "r" : "-");
	ft_printf ((data->sdir.st_mode & S_IWGRP) ? "w" : "-");
	ft_printf ((data->sdir.st_mode & S_IXGRP) ? "x" : "-");
	ft_printf ((data->sdir.st_mode & S_IROTH) ? "r" : "-");
	ft_printf ((data->sdir.st_mode & S_IWOTH) ? "w" : "-");
	ft_printf ((data->sdir.st_mode & S_IXOTH) ? "x" : "-");
	ft_printf("	%d	%s	%s	%d	",
			data->sdir.st_nlink, data->pws->pw_name, data->grp->gr_name, data->sdir.st_size);
	ft_printf("%.12s	", 4+ctime(&data->sdir.st_mtime));
}

void      plus(t_ls *data)
{
	char *tp = NULL;
	char *tt= NULL;

	data->block = 0;
	if ((data->dir = opendir(data->str)) != NULL)
	{
		while ((data->r = readdir(data->dir)) != NULL)
		{
			if (data->c == 'd')
			{
				tp = ft_strjoin(data->str,"/");
				tt = ft_strjoin(tp, data->r->d_name);
				lstat(tt, &data->sdir);
				free (tp);
				free (tt);
			}
			data->block += data->sdir.st_blocks;
		}
		closedir(data->dir);
	}
}

void      size_dname(t_ls *data)
{
	data->size_d = 0;
	data->word_d = 0;
	data->len = 0;
	if ((data->dir = opendir(data->str)) != NULL)
	{
		while ((data->r = readdir(data->dir)) != NULL)
		{
			data->len = (data->len > ft_strlen(data->r->d_name)) ? data->len : ft_strlen(data->r->d_name);
			if (data->r->d_name[0] != '.')
				data->size_d += 1;
			data->word_d += 1;
		}
		closedir(data->dir);
	}
}