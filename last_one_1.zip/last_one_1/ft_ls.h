/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zael-mab <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/03/02 23:14:45 by zael-mab          #+#    #+#             */
/*   Updated: 2020/03/03 05:30:01 by zael-mab         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifndef FT_LS_H
# define FT_LS_H

# include <sys/types.h>
# include <sys/stat.h>
# include <dirent.h>
# include "libft/libft.h"
# include <pwd.h>
# include <grp.h>
# include <uuid/uuid.h>
# include <time.h>
# include <stdio.h>

# define A  1
# define L 	2
# define RR 4
# define RN 8
# define T 	16

typedef struct s_ls
{
	DIR				*dir;
	struct dirent	*r;
	struct stat		sdir;
	struct passwd	*pws;
	struct group	*grp;
	unsigned short	op;
	char 			*linkname;
	char			*str;
	// char			*str1;
	int				len;
	size_t 			j;
	int			 	flag;
	char 			c;
	size_t 			block;
	char 			x;
	unsigned short	size_d;
	int				word_d;
	char 			*s;
	char			**tab;
	char			**tab1;
	char			*tab0[2];
	int 			jmper;
	int 			z;
	char *error;
	char			*linkx;
	char			*linky;
	char			*linkz;
}				t_ls;

typedef struct s_open
{
	int i;
    DIR             *dir;
    struct dirent   *r;
    struct stat     s;
    char            *link;
    char            *Directory[2];
    char            **tab;
    char            *string[99];
	char            *str[99];
}               t_open;

void 	link_name(t_ls *data);
void    ft_detail(t_ls *data);
char	f_type(mode_t mode);
void 	option(char *s, t_ls *data);
void	plus(t_ls *data);
void	size_dname(t_ls *data);
void	s_orting0(t_ls *data);
void	s_orting1(t_ls *data);
void    s_orting2(t_ls *data);
void	launch_r(t_ls *data);
void	a(t_ls *data);
void	ft_ls_l(t_ls *data);
void open_directory(char *str, t_ls *data);

#endif
