				
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tst.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zael-mab <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/03/03 04:26:49 by zael-mab          #+#    #+#             */
/*   Updated: 2020/03/03 05:39:02 by zael-mab         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

////////////////////////////////////////////////////
void	l(t_ls *data)
{
	if (data->c == 'd' && data->flag != -1)
	{
		size_dname(data);
		s_orting0(data);
	}
}

///////////////////////////////////////////////
void	a(t_ls *data)
{
	if (data->c == 'd' && data->flag != -1)
	{
		size_dname(data);
		s_orting0(data);
	}
}



////////////////////////////////////////////////////
void	ft_ls_l(t_ls *data)
{
	if (lstat(data->str, &data->sdir) == -1)
		data->flag = -1;
	data->c = f_type(data->sdir.st_mode);
	
// ****************************************
	plus(data);

	if ((data->op & L) && data->flag != -1 && (data->sdir.st_mode & S_IRUSR))
		l(data);
	
	if (!(data->op & L)  && data->flag != -1 && (data->sdir.st_mode & S_IRUSR))
		a(data);
}



///////////////////////////////////////////////////
int			main(int ac, char **av)
{
	t_ls	data;
	int		i;
	int		j;
	int 	jumper;

	j = 1;
	i = 0;
	jumper = 1;
	ft_bzero(&data, sizeof (data));
	if (ac >= 2)
	{


// ******************************************************
		
		
		while (ac >= 2 && jumper < ac)
		{
			if (av[jumper][0] == '-')
				option(av[jumper], &data);
			else
				break ;
			jumper++;
		}
		
		j = jumper;
		while (ac >= 2 && j < ac)
		{
			if (av[j][0] != '-')
			{
				if (jumper == j)
					j = 0;
				break ;
			}
			j++;
		}
// ******************************************************
		
		int y; //s_orting2 same
		char *holder;
		
		data.z = jumper - 1;
		while (++data.z < ac)
		{
			y = data.z - 1;
			while (++y < ac)
				if (ft_strcmp (av[data.z], av[y]) > 0)
				{
					holder = av[data.z];
					av[data.z] = av[y];
					av[y] = holder;
				}
		}

		j = jumper;
		

// ********************************************************
		i = j - 1;		
		while (av[++i])
		{
			data.flag = 0;
			data.str = av[i];
			if (lstat(data.str, &data.sdir) == -1)
			{
				data.flag = -1;
				ft_printf ("ft_ls: %s: No such file or directory\n", data.str);
			}
		}

// ********************************************************

		data.z = jumper - 1;
		while (++data.z < ac)
		{
			y = data.z - 1;
			while (++y < ac)
				if (ft_strcmp (av[data.z], av[y]) < 0 && (data.op & RN))
				{
					holder = av[data.z];
					av[data.z] = av[y];
					av[y] = holder;
				}
		}
// ********************************************************

		data.z = 0;
		if (ac == jumper && av[1][0] == '-')
		{
			data.str = ft_strdup(".");
			ft_ls_l(&data);
		}
		data.j = ac - j;


// **********************************************************
		i = j - 1;		
		while (av[++i])
		{
			data.flag = 0;
			data.str = av[i];
			if (lstat(data.str, &data.sdir) == -1)
				data.flag = -1;
			data.c = f_type(data.sdir.st_mode);
			if ((data.c == '-' || data.c == 'l') && data.flag != -1)
			{
				if (data.op & L)
					ft_detail(&data);
				ft_printf ("%s\n", data.str);
			}
		}


//********************************************************
		i = j - 1;
		data.j = ac - j;
		j--;
		while (av[++j])
		{
			data.flag = 0;
			data.str = av[j];
			ft_ls_l(&data);
			
		}
		
// ********************************************************
		while (av[++i])
		{
			data.flag = 0;
			data.str = av[i];
			if (lstat(data.str, &data.sdir) == -1)
				data.flag = -1;
				data.c = f_type(data.sdir.st_mode);
			if (!(data.sdir.st_mode & S_IRUSR) && (data.flag != -1) && data.c == 'd')
				ft_printf ("\n%s:\nft_ls: %s: Permission denied\n", data.str, data.str); 
		}
// ******************************************************
	}
	if (ac == 1)
	{
		data.str = ft_strdup(".");
		ft_ls_l(&data);
		free (data.str);
	}
}